package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.TradieViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: TradieViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen(viewModel)
            }
        }
    }
}

// Custom Premium Palette - High Density Theme
val AgritechDarkGreen = Color(0xFF1D192B) // Deep purple-slate
val AgritechMediumGreen = Color(0xFF6750A4) // Primary purple
val AgritechTeal = Color(0xFF4F378B) // Mid purple
val AgritechAccentGold = Color(0xFFD0BCFF) // Accent light purple
val CreamBackground = Color(0xFFFDF8F6) // Warm light background
val DarkText = Color(0xFF1D1B1E) // Dark text
val CardBorder = Color(0xFFCAC4D0) // Card border/divider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: TradieViewModel) {
    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val primaryUser by viewModel.primaryUser.collectAsStateWithLifecycle()
    val auditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var showRoleSelector by remember { mutableStateOf(false) }
    var showBioKYC by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AgritechAccentGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "App Icon",
                                tint = AgritechDarkGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "TRADIE",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 22.sp
                        )
                    }
                },
                actions = {
                    // Profile/Wallet Quick Badge
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AgritechMediumGreen),
                        shape = RoundedCornerShape(20.dp),
                        onClick = { showBioKYC = true },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Coins",
                                tint = AgritechAccentGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${primaryUser?.tradieCoins ?: 1000} Coins",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Active Role Quick Switch Button
                    TextButton(
                        onClick = { showRoleSelector = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = AgritechAccentGold)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = activeRole,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch",
                                tint = AgritechAccentGold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AgritechDarkGreen,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = CreamBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Role Switch Shortcut Bar (Dynamic Chips)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AgritechDarkGreen)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val roles = listOf("Producer", "Agent", "Buyer", "Transporter", "Warehouse", "Finance", "TPV", "Admin")
                roles.forEach { r ->
                    val isSelected = r == activeRole
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.switchRole(r) },
                        label = { Text(r, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AgritechAccentGold,
                            selectedLabelColor = AgritechDarkGreen,
                            containerColor = AgritechMediumGreen.copy(alpha = 0.5f),
                            labelColor = Color.White.copy(alpha = 0.8f)
                        )
                    )
                }
            }

            // Core Layout: Role-Based Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (activeRole) {
                    "Producer" -> ProducerScreen(viewModel)
                    "Agent" -> AgentScreen(viewModel)
                    "Buyer" -> BuyerScreen(viewModel)
                    "Transporter" -> TransporterScreen(viewModel)
                    "Warehouse" -> WarehouseScreen(viewModel)
                    "Finance" -> FinanceScreen(viewModel)
                    "TPV" -> TpvScreen(viewModel)
                    "Admin" -> AdminScreen(viewModel)
                }
            }
        }

        // Role Selector Popup Modal
        if (showRoleSelector) {
            RoleSelectorDialog(
                currentRole = activeRole,
                onDismiss = { showRoleSelector = false },
                onSelectRole = { role ->
                    viewModel.switchRole(role)
                    showRoleSelector = false
                    Toast.makeText(context, "Switched to $role Workspace", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // User Bio-KYC Profile Information Dialog
        if (showBioKYC) {
            BioKYCDialog(
                user = primaryUser,
                onDismiss = { showBioKYC = false },
                onCompleteKYC = {
                    viewModel.completePrimaryUserBioKYC {
                        Toast.makeText(context, "Bio-KYC Verification Completed!", Toast.LENGTH_LONG).show()
                    }
                    showBioKYC = false
                }
            )
        }
    }
}

// ==============================================================================
// 1. PRODUCER ECOSYSTEM MODULE
// ==============================================================================
@Composable
fun ProducerScreen(viewModel: TradieViewModel) {
    val myFarms by viewModel.myFarms.collectAsStateWithLifecycle()
    val myLots by viewModel.myLots.collectAsStateWithLifecycle()

    var showAddPlot by remember { mutableStateOf(false) }
    var showTokenizeLot by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card with custom image background
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_tradie_banner),
                        contentDescription = "Wheat Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Producer Dashboard",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Welcome back, Anil! Track cultivation, tokenize crop assets, and apply for NBFC advances securely.",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { showAddPlot = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Plot")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Register Farm", fontSize = 13.sp)
                }

                Button(
                    onClick = { showTokenizeLot = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Tokenize")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tokenize Crop", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Farm Plots Section
        item {
            SectionHeader(title = "Your Cultivated Land & Plots", icon = Icons.Default.LocationOn)
        }

        if (myFarms.isEmpty()) {
            item {
                EmptyStateCard(text = "No registered farm plots. Click 'Register Farm' to begin geo-fencing cultivation details.")
            }
        } else {
            items(myFarms) { farm ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = farm.farmName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(text = "Survey: ${farm.surveyNumber}  •  Area: ${farm.areaAcres} Acres", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "Geo-Coordinates: ${String.format("%.4f", farm.geoLat)}, ${String.format("%.4f", farm.geoLong)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AgritechTeal
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AgritechMediumGreen.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.LocationOn, contentDescription = "GPS", tint = AgritechTeal)
                        }
                    }
                }
            }
        }

        // Tokenized Lots Section
        item {
            SectionHeader(title = "Digital Twin Lots & Traceability Assets", icon = Icons.Default.List)
        }

        if (myLots.isEmpty()) {
            item {
                EmptyStateCard(text = "No crop lots tokenized yet. Settle harvest yields into tokenized lots to begin logistics and selling.")
            }
        } else {
            items(myLots) { lot ->
                LotAssetItem(lot = lot, onBookTransport = {
                    viewModel.bookTransportForLot(lot.id, "Sher Singh Logistics")
                })
            }
        }
    }

    // Add Plot Dialog
    if (showAddPlot) {
        AddPlotDialog(
            onDismiss = { showAddPlot = false },
            onAdd = { name, survey, acres ->
                viewModel.addFarmPlot(name, survey, acres, 16.8 + Math.random() * 0.1, 74.5 + Math.random() * 0.1)
                showAddPlot = false
            }
        )
    }

    // Tokenize Lot Dialog
    if (showTokenizeLot) {
        TokenizeLotDialog(
            farms = myFarms,
            onDismiss = { showTokenizeLot = false },
            onTokenize = { farmId, commodity, variety, grade, quantity, price, selfQual ->
                viewModel.createAndTokenizeLot(farmId, commodity, variety, grade, quantity, price, selfQual)
                showTokenizeLot = false
            }
        )
    }
}

@Composable
fun SectionHeader(title: String, icon: ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = AgritechMediumGreen, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
    }
}

@Composable
fun EmptyStateCard(text: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Empty",
                tint = Color.Gray.copy(alpha = 0.5f),
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = text,
                color = Color.Gray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun LotAssetItem(lot: CommodityLotEntity, onBookTransport: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, if (lot.status == "PLEDGED") AgritechAccentGold else CardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Token ID + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lot.tokenId,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = AgritechTeal
                )
                StatusBadge(status = lot.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Body: Commodity details
            Text(
                text = "${lot.commodityName} (${lot.variety})",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = AgritechDarkGreen
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Qty: ${lot.quantityKg} Kg  •  Min Floor: ₹${lot.offerPricePerKg}/Kg",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Traceability indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TraceTag(label = "Moisture: ${lot.moistureContent}%", active = true)
                TraceTag(label = "Trash: ${lot.trashPercentage}%", active = true)
                if (lot.thirdPartyVerified) {
                    TraceTag(label = "Assayed ✓", active = true, color = AgritechTeal)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Actions for the Lot depending on status
            when (lot.status) {
                "TOKENIZED" -> {
                    Button(
                        onClick = onBookTransport,
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Book", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Initiate Transport Booking", fontSize = 12.sp)
                    }
                }
                "TRANSPORT_BOOKED" -> {
                    Text(
                        text = "🚚 Trip assigned with Sher Singh Cargo. Waiting for pickup OTP verification.",
                        color = AgritechTeal,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                "RECEIVED_AT_YARD" -> {
                    Text(
                        text = "🏢 Lot arrived safely at Mandi Yard. Undergoing Weighbridge Entry and Agent scheduling.",
                        color = AgritechTeal,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                "IN_AUCTION" -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AgritechAccentGold.copy(alpha = 0.1f))
                            .padding(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = AgritechTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Active dynamic auction running on this lot.", color = AgritechDarkGreen, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                "STORED" -> {
                    Text(
                        text = "🔑 Safe-kept in bonded warehouse. Eligible for bill discounting & NABARD advances.",
                        color = AgritechMediumGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                "PLEDGED" -> {
                    Text(
                        text = "🔒 Collateralized under NABARD pledge. 70% LTV liquidity distributed.",
                        color = Color(0xFF9E7E0D),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (bgColor, textColor) = when (status) {
        "CREATED", "TOKENIZED" -> Pair(Color(0xFFE3F2FD), Color(0xFF0D47A1))
        "TRANSPORT_BOOKED" -> Pair(Color(0xFFFFF3E0), Color(0xFFE65100))
        "RECEIVED_AT_YARD" -> Pair(Color(0xFFEDE7F6), Color(0xFF4A148C))
        "IN_AUCTION" -> Pair(Color(0xFFE8F5E9), Color(0xFF1B5E20))
        "SOLD" -> Pair(Color(0xFFF3E5F5), Color(0xFF4A148C))
        "STORED" -> Pair(Color(0xFFE0F2F1), Color(0xFF004D40))
        "PLEDGED" -> Pair(Color(0xFFFFFDE7), Color(0xFFF57F17))
        else -> Pair(Color.Gray.copy(alpha = 0.1f), Color.DarkGray)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text = status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textColor)
    }
}

@Composable
fun TraceTag(label: String, active: Boolean, color: Color = Color.Gray) {
    Box(
        modifier = Modifier
            .border(0.5.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .background(if (active) color.copy(alpha = 0.05f) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text = label, fontSize = 11.sp, color = if (active) color else Color.Gray, fontWeight = FontWeight.Medium)
    }
}

// ==============================================================================
// 2. COMMISSION AGENT ECOSYSTEM MODULE
// ==============================================================================
@Composable
fun AgentScreen(viewModel: TradieViewModel) {
    val lots by viewModel.allLots.collectAsStateWithLifecycle()
    val auctions by viewModel.allAuctions.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedLotForAuction by remember { mutableStateOf<CommodityLotEntity?>(null) }
    var selectedLotForWeighment by remember { mutableStateOf<CommodityLotEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgritechDarkGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Commission Agent Desk", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Yard: Mandi Gate No. 2  •  Operator: Rajesh Mandi Agent", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        // Active lots awaiting Weighbridge Sync
        item {
            SectionHeader(title = "Lots Awaiting Weighbridge Sync", icon = Icons.Default.List)
        }

        val weighableLots = lots.filter { it.status == "RECEIVED_AT_YARD" }
        if (weighableLots.isEmpty()) {
            item {
                EmptyStateCard(text = "No pending lots awaiting weighbridge processing. Lots appear here once delivery is completed by transporters.")
            }
        } else {
            items(weighableLots) { lot ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = lot.commodityName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(text = "Owner: ${lot.producerName}  •  Declared: ${lot.quantityKg} Kg", fontSize = 12.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = { selectedLotForWeighment = lot },
                            colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Sync Scale", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Active lots awaiting Auction Scheduling
        item {
            SectionHeader(title = "Schedule Live Mandi Auctions", icon = Icons.Default.PlayArrow)
        }

        val schedulableLots = lots.filter { it.status == "RECEIVED_AT_YARD" && lotIdNotActiveAuction(it.id, auctions) }
        if (schedulableLots.isEmpty()) {
            item {
                EmptyStateCard(text = "No verified stocks awaiting auction listing. Complete weighbridge sync on lots first.")
            }
        } else {
            items(schedulableLots) { lot ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = lot.commodityName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(text = "Final Weight: ${lot.quantityKg} Kg  •  Min Base: ₹${lot.offerPricePerKg}/Kg", fontSize = 12.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = { selectedLotForAuction = lot },
                            colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Start Bid", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Weighbridge Dialog
    if (selectedLotForWeighment != null) {
        WeighbridgeSyncDialog(
            lot = selectedLotForWeighment!!,
            onDismiss = { selectedLotForWeighment = null },
            onWeigh = { w1, w2 ->
                viewModel.performWeighbridgeEntry(selectedLotForWeighment!!.id, w1, w2) { mismatch ->
                    if (mismatch) {
                        Toast.makeText(context, "⚠️ Mismatch detected! Automated dispute log generated.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✓ Weight verified & synchronized successfully.", Toast.LENGTH_SHORT).show()
                    }
                }
                selectedLotForWeighment = null
            }
        )
    }

    // Auction Listing Scheduler Dialog
    if (selectedLotForAuction != null) {
        ScheduleAuctionDialog(
            lot = selectedLotForAuction!!,
            onDismiss = { selectedLotForAuction = null },
            onSchedule = { floor, hours ->
                viewModel.scheduleAuctionForLot(selectedLotForAuction!!.id, floor, hours)
                selectedLotForAuction = null
                Toast.makeText(context, "Auction scheduled & published successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

fun lotIdNotActiveAuction(lotId: Int, auctions: List<AuctionEntity>): Boolean {
    return auctions.none { it.lotId == lotId && it.status == "LIVE" }
}

// ==============================================================================
// 3. BUYER / TRADER DISCOVERY MODULE
// ==============================================================================
@Composable
fun BuyerScreen(viewModel: TradieViewModel) {
    val auctions by viewModel.allAuctions.collectAsStateWithLifecycle()
    val lots by viewModel.allLots.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedAuctionForBid by remember { mutableStateOf<AuctionEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgritechDarkGreen)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Commodity Marketplace", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Real-time bidding room linked directly with accredited lab assay certificates.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        item {
            SectionHeader(title = "Live Mandi Auction Rooms", icon = Icons.Default.PlayArrow)
        }

        val activeAuctions = auctions.filter { it.status == "LIVE" }
        if (activeAuctions.isEmpty()) {
            item {
                EmptyStateCard(text = "No active commodity auctions running right now. Switch to 'Agent' workspace to list lots.")
            }
        } else {
            items(activeAuctions) { auction ->
                val relatedLot = lots.find { it.id == auction.lotId }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, AgritechTeal.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Auction #${auction.id}", fontWeight = FontWeight.Bold, color = AgritechTeal, fontSize = 12.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Red))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("LIVE", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = auction.commodityName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
                        Text(text = "Total Load: ${auction.quantityKg} Kg  •  Floor: ₹${auction.floorPricePerKg}/Kg", fontSize = 12.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(8.dp))

                        // High-contrast bidding indicator
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AgritechAccentGold.copy(alpha = 0.1f))
                                .padding(12.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Current Highest Bid", fontSize = 11.sp, color = Color.DarkGray)
                                Text("₹${auction.currentPricePerKg}/Kg", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Leader", fontSize = 11.sp, color = Color.DarkGray)
                                Text(auction.highestBidderName.ifEmpty { "No Bids Placed" }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AgritechTeal)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Close/Settle option for Demo Ease
                            Button(
                                onClick = { viewModel.closeAuctionAndAcceptWinner(auction.id) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = AgritechDarkGreen),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Settle Trade", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { selectedAuctionForBid = auction },
                                modifier = Modifier.weight(1.2f),
                                colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Send, contentDescription = "Bid", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Enter Bid Room", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedAuctionForBid != null) {
        val bids by viewModel.getBidsForAuctionFlow(selectedAuctionForBid!!.id).collectAsStateWithLifecycle(emptyList())
        BidRoomDialog(
            auction = selectedAuctionForBid!!,
            bids = bids,
            onDismiss = { selectedAuctionForBid = null },
            onPlaceBid = { bidValue ->
                viewModel.placeBid(selectedAuctionForBid!!.id, bidValue, 3, "Subhash Grain Traders") { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) {
                        // Refresh the dialog reference
                        selectedAuctionForBid = selectedAuctionForBid!!.copy(currentPricePerKg = bidValue, highestBidderName = "Subhash Grain Traders")
                    }
                }
            }
        )
    }
}

// ==============================================================================
// 4. TRANSPORTER / LOGISTICS MODULE
// ==============================================================================
@Composable
fun TransporterScreen(viewModel: TradieViewModel) {
    val trips by viewModel.allTransportTrips.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedTripForPickupOtp by remember { mutableStateOf<TransportTripEntity?>(null) }
    var selectedTripForDeliveryOtp by remember { mutableStateOf<TransportTripEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgritechDarkGreen)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Transport & Fleet Console", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Transporter: Sher Singh Logistics  •  Secure OTP Handoffs", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        item {
            SectionHeader(title = "Your Booked Cargo & Active Trips", icon = Icons.Default.PlayArrow)
        }

        if (trips.isEmpty()) {
            item {
                EmptyStateCard(text = "No transport bookings assigned. Switch to 'Producer' workspace to create and book transport on lots.")
            }
        } else {
            items(trips) { trip ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Trip ID: #TRP-${trip.id}", fontWeight = FontWeight.Bold, color = AgritechTeal)
                            StatusBadge(status = trip.status)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = "${trip.commodityName} (${trip.quantityKg} Kg)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
                        Text(text = "Driver: ${trip.driverName}  •  Current Location: ${trip.currentLocation}", fontSize = 12.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(12.dp))

                        when (trip.status) {
                            "BOOKED" -> {
                                Button(
                                    onClick = { selectedTripForPickupOtp = trip },
                                    colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Verify Producer Pickup OTP")
                                }
                            }
                            "IN_TRANSIT" -> {
                                Button(
                                    onClick = { selectedTripForDeliveryOtp = trip },
                                    colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Verify Yard Manager Delivery OTP", fontWeight = FontWeight.Bold)
                                }
                            }
                            "DELIVERED" -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(AgritechTeal.copy(alpha = 0.1f))
                                        .padding(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Completed", tint = AgritechTeal)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Delivery securely completed. Custody handed over.", color = AgritechTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Pickup OTP Dialog
    if (selectedTripForPickupOtp != null) {
        OtpHandoffDialog(
            title = "Verify Producer Pickup (OTP-HAND)",
            placeholder = "Enter 4-digit OTP provided by Producer Anil",
            onDismiss = { selectedTripForPickupOtp = null },
            onSubmit = { code ->
                viewModel.performPickupHandoff(selectedTripForPickupOtp!!.id, code) { correct ->
                    if (correct) {
                        Toast.makeText(context, "Pickup handoff completed successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid Pickup OTP! Handoff denied.", Toast.LENGTH_LONG).show()
                    }
                }
                selectedTripForPickupOtp = null
            }
        )
    }

    // Delivery OTP Dialog
    if (selectedTripForDeliveryOtp != null) {
        OtpHandoffDialog(
            title = "Verify Mandi Delivery (OTP-DELIV)",
            placeholder = "Enter 4-digit OTP provided by Yard Security Rajesh",
            onDismiss = { selectedTripForDeliveryOtp = null },
            onSubmit = { code ->
                viewModel.performDeliveryHandoff(selectedTripForDeliveryOtp!!.id, code) { correct ->
                    if (correct) {
                        Toast.makeText(context, "Delivery handoff completed successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid Delivery OTP! Handoff denied.", Toast.LENGTH_LONG).show()
                    }
                }
                selectedTripForDeliveryOtp = null
            }
        )
    }
}

// ==============================================================================
// 5. WAREHOUSE & STORAGE ECOSYSTEM MODULE
// ==============================================================================
@Composable
fun WarehouseScreen(viewModel: TradieViewModel) {
    val lots by viewModel.allLots.collectAsStateWithLifecycle()
    val receipts by viewModel.allWarehouseReceipts.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var lotIdForReceipt by remember { mutableStateOf<Int?>(null) }
    var selectedLotIdDetails by remember { mutableStateOf<CommodityLotEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgritechDarkGreen)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Bonded Warehouse Desk", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Facility: State Warehouse Corp - Bonded Chamber 4", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        // Climate Control Panel Widget
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, CardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Active Warehouse Climate Sync", fontWeight = FontWeight.Bold, color = AgritechDarkGreen, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Stored Temp", fontSize = 11.sp, color = Color.Gray)
                            Text("22.4 °C", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AgritechTeal)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Relative Humidity", fontSize = 11.sp, color = Color.Gray)
                            Text("54.2%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AgritechTeal)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Fumigation Status", fontSize = 11.sp, color = Color.Gray)
                            Text("ACTIVE ✓", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Lots Awaiting Warehouse Receipts", icon = Icons.Default.Add)
        }

        // Lots eligible to be stored (status RECEIVED_AT_YARD or SOLD awaiting delivery)
        val storableLots = lots.filter { it.status == "RECEIVED_AT_YARD" }
        if (storableLots.isEmpty()) {
            item {
                EmptyStateCard(text = "No pending lots awaiting storage intake. Settle lots at Mandi Yard first.")
            }
        } else {
            items(storableLots) { lot ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = lot.commodityName, fontWeight = FontWeight.Bold)
                            Text(text = "Owner: ${lot.producerName}  •  ${lot.quantityKg} Kg", fontSize = 12.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = {
                                viewModel.generateWarehouseReceipt(lot.id, "State Warehouse Corp - Chamber 4")
                                Toast.makeText(context, "Negotiable warehouse storage receipt generated successfully!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Store", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Issued Negotiable Receipts (NWRs)", icon = Icons.Default.List)
        }

        if (receipts.isEmpty()) {
            item {
                EmptyStateCard(text = "No active warehouse receipts generated in this chamber.")
            }
        } else {
            items(receipts) { receipt ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NWR #WR-${receipt.id}",
                                fontWeight = FontWeight.Bold,
                                color = AgritechTeal,
                                fontFamily = FontFamily.Monospace
                            )
                            StatusBadge(status = receipt.status)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = "${receipt.commodityName} (${receipt.quantityKg} Kg)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
                        Text(text = "Facility: ${receipt.warehouseName}", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 6. FINANCE & NBFC MODULE
// --- Loan Requests / Pledge Advances ---
// ==============================================================================
@Composable
fun FinanceScreen(viewModel: TradieViewModel) {
    val receipts by viewModel.allWarehouseReceipts.collectAsStateWithLifecycle()
    val primaryUser by viewModel.primaryUser.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Ecosystem Finance Hub",
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = AgritechMediumGreen)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("NABARD & NBFC Credit Lines", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    text = "Apply for swift pledge financing against certified Warehouse Receipts. Disburses up to 70% Loan-to-Value (LTV) within minutes.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        SectionHeader(title = "Accredited Warehouse Receipts Eligible for Loan", icon = Icons.Default.Star)

        Spacer(modifier = Modifier.height(8.dp))

        val pledgeableReceipts = receipts.filter { it.status == "ACTIVE" }
        if (pledgeableReceipts.isEmpty()) {
            EmptyStateCard(text = "No receipts currently eligible. Settle dynamic auctions or deposit lots in bonded warehouses first.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(pledgeableReceipts) { receipt ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, CardBorder)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "NWR #WR-${receipt.id}", fontWeight = FontWeight.Bold, color = AgritechTeal)
                                Text("LTV Limit: 70%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AgritechAccentGold)
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(text = "${receipt.commodityName} (${receipt.quantityKg} Kg)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AgritechDarkGreen)
                            Text(text = "Stored Facility: ${receipt.warehouseName}", fontSize = 12.sp, color = Color.Gray)

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    viewModel.applyForPledgeLoan(receipt.id) {
                                        // On Complete
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = "Apply", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Apply and Disburse 70% Pledge Advance", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 7. THIRD PARTY VERIFICATION & LAB ASSAYER SCREEN
// ==============================================================================
@Composable
fun TpvScreen(viewModel: TradieViewModel) {
    val lots by viewModel.allLots.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedLotForAssay by remember { mutableStateOf<CommodityLotEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Accredited Lab Assaying Desk",
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = AgritechDarkGreen)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Official Assayer: SGS Agrochemical Labs", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Certify moisture levels, purity, trash percentages, and grade tokenized lots to enable high trust index rankings.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        }

        SectionHeader(title = "Tokenized Lots Awaiting Quality Assaying", icon = Icons.Default.Check)

        Spacer(modifier = Modifier.height(8.dp))

        val unverifiedLots = lots.filter { !it.thirdPartyVerified }
        if (unverifiedLots.isEmpty()) {
            EmptyStateCard(text = "All active lots are fully certified and assayed.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(unverifiedLots) { lot ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, CardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = lot.commodityName, fontWeight = FontWeight.Bold)
                                Text(text = "Owner: ${lot.producerName}  •  ${lot.quantityKg} Kg", fontSize = 12.sp, color = Color.Gray)
                                Text(text = "Self-Declared: ${lot.selfDeclaredQuality}", fontSize = 11.sp, color = AgritechTeal)
                            }
                            Button(
                                onClick = { selectedLotForAssay = lot },
                                colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Assay", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedLotForAssay != null) {
        LabAssayDialog(
            lot = selectedLotForAssay!!,
            onDismiss = { selectedLotForAssay = null },
            onSubmitAssay = { moisture, trash, grade ->
                viewModel.submitQualityAssay(selectedLotForAssay!!.id, "SGS Assayers", moisture, trash, grade)
                selectedLotForAssay = null
                Toast.makeText(context, "Traceability assay certificate issued successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

// ==============================================================================
// 8. ADMIN / AUDIT LEDGER / DISPUTES HUB
// ==============================================================================
@Composable
fun AdminScreen(viewModel: TradieViewModel) {
    val lots by viewModel.allLots.collectAsStateWithLifecycle()
    val disputes by viewModel.allDisputes.collectAsStateWithLifecycle()
    val auditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedDisputeForResolution by remember { mutableStateOf<DisputeEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Central Operations Control Tower",
                style = androidx.compose.material3.MaterialTheme.typography.headlineMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
            )
        }

        // Live Ecosystem KPI Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KPICard(title = "Ecosystem Lots", count = "${lots.size}", modifier = Modifier.weight(1f))
                KPICard(title = "Open Disputes", count = "${disputes.filter { it.status == "OPEN" }.size}", modifier = Modifier.weight(1f), color = Color(0xFFD32F2F))
                KPICard(title = "Ledger Audit Trails", count = "${auditLogs.size}", modifier = Modifier.weight(1f), color = AgritechTeal)
            }
        }

        // Dispute Settlement Queue
        item {
            SectionHeader(title = "Disputes & Mismatches Mediation Queue", icon = Icons.Default.Warning)
        }

        val activeDisputes = disputes.filter { it.status == "OPEN" }
        if (activeDisputes.isEmpty()) {
            item {
                EmptyStateCard(text = "Zero disputes raised! The weighbridge, logistics, and dynamic bidding flows are completely in sync.")
            }
        } else {
            items(activeDisputes) { dispute ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "DISPUTE #${dispute.id} [${dispute.entityType}]", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 12.sp)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Red.copy(alpha = 0.1f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("OPEN", color = Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = dispute.reason, fontSize = 14.sp, color = Color.DarkGray)
                        Text(text = "Raised by: ${dispute.initiatorName}", fontSize = 11.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { selectedDisputeForResolution = dispute },
                            colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Resolve Dispute / Override")
                        }
                    }
                }
            }
        }

        // Complete Audit Ledger Section
        item {
            SectionHeader(title = "Immutable Cryptographic Audit Trail", icon = Icons.Default.Build)
        }

        if (auditLogs.isEmpty()) {
            item {
                EmptyStateCard(text = "Ledger trail is currently empty.")
            }
        } else {
            items(auditLogs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LOG #${log.id} • ${log.action}",
                                fontWeight = FontWeight.Bold,
                                color = AgritechTeal,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = formatTime(log.timestamp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = log.details, fontSize = 13.sp, color = DarkText)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = "Auth-Verifier: ${log.userName}", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }

    if (selectedDisputeForResolution != null) {
        ResolveDisputeDialog(
            dispute = selectedDisputeForResolution!!,
            onDismiss = { selectedDisputeForResolution = null },
            onResolve = { terms ->
                viewModel.resolveDispute(selectedDisputeForResolution!!.id, terms)
                selectedDisputeForResolution = null
                Toast.makeText(context, "Dispute resolved successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun KPICard(title: String, count: String, modifier: Modifier = Modifier, color: Color = AgritechDarkGreen) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = count, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

fun formatTime(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp))
}

// ==============================================================================
// CUSTOM POPUPS AND MODAL DIALOGS
// ==============================================================================
@Composable
fun RoleSelectorDialog(
    currentRole: String,
    onDismiss: () -> Unit,
    onSelectRole: (String) -> Unit
) {
    val rolesList = listOf("Producer", "Agent", "Buyer", "Transporter", "Warehouse", "Finance", "TPV", "Admin")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Select Operator Role Workspace",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = AgritechDarkGreen
                )
                Spacer(modifier = Modifier.height(16.dp))

                rolesList.forEach { role ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectRole(role) }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = role, fontSize = 16.sp, color = DarkText)
                        if (role == currentRole) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = "Current", tint = AgritechTeal)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BioKYCDialog(
    user: UserEntity?,
    onDismiss: () -> Unit,
    onCompleteKYC: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "KYC",
                    tint = AgritechAccentGold,
                    modifier = Modifier.size(64.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Identity & Bio-KYC Portal",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = AgritechDarkGreen
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Your digital twin credentials represent legal custody and ownership. Authenticate using biometric or government registry files.",
                    fontSize = 13.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Operator Name", fontSize = 11.sp, color = Color.Gray)
                        Text(user?.name ?: "Anil Kumar", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("KYC Verification Status", fontSize = 11.sp, color = Color.Gray)
                        Text(
                            text = user?.kycStatus ?: "VERIFIED",
                            fontWeight = FontWeight.Bold,
                            color = if (user?.kycStatus == "VERIFIED") AgritechTeal else Color.Red
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Close")
                    }
                    if (user?.kycStatus != "VERIFIED") {
                        Button(
                            onClick = onCompleteKYC,
                            colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("Complete Verification")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddPlotDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var survey by remember { mutableStateOf("") }
    var acres by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Register Cultivation Land Plot", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Plot Name (e.g. Sona Valley B)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = survey,
                    onValueChange = { survey = it },
                    label = { Text("Government Survey Number") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = acres,
                    onValueChange = { acres = it },
                    label = { Text("Area Size (Acres)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val area = acres.toDoubleOrNull() ?: 1.0
                            onAdd(name, survey, area)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Confirm Geo-Fencing")
                    }
                }
            }
        }
    }
}

@Composable
fun TokenizeLotDialog(
    farms: List<FarmEntity>,
    onDismiss: () -> Unit,
    onTokenize: (Int, String, String, String, Double, Double, String) -> Unit
) {
    var selectedFarmIndex by remember { mutableStateOf(0) }
    var commodityName by remember { mutableStateOf("") }
    var variety by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var offerPrice by remember { mutableStateOf("") }
    var selfQual by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Tokenize Harvest Lot", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Link to Source Plot", fontSize = 12.sp, color = Color.Gray)
                if (farms.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        farms.forEachIndexed { index, farm ->
                            FilterChip(
                                selected = index == selectedFarmIndex,
                                onClick = { selectedFarmIndex = index },
                                label = { Text(farm.farmName, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = commodityName,
                    onValueChange = { commodityName = it },
                    label = { Text("Commodity (e.g. Sona Masuri Rice)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = variety,
                    onValueChange = { variety = it },
                    label = { Text("Variety/Type (e.g. Aged Premium)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("Total Harvest Quantity (Kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = offerPrice,
                    onValueChange = { offerPrice = it },
                    label = { Text("Reserve Offer Price (₹/Kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = selfQual,
                    onValueChange = { selfQual = it },
                    label = { Text("Quality self-declaration note") },
                    placeholder = { Text("e.g. Moisture 12%, fully dried") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val fId = if (farms.isNotEmpty()) farms[selectedFarmIndex].id else 0
                            val q = quantity.toDoubleOrNull() ?: 100.0
                            val p = offerPrice.toDoubleOrNull() ?: 10.0
                            onTokenize(fId, commodityName, variety, "A", q, p, selfQual)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Mint Asset Token", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun OtpHandoffDialog(
    title: String,
    placeholder: String,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var otp by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(12.dp))

                Icon(imageVector = Icons.Default.Lock, contentDescription = "OTP", tint = AgritechTeal, modifier = Modifier.size(48.dp))

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = otp,
                    onValueChange = { if (it.length <= 4) otp = it },
                    label = { Text(placeholder) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onSubmit(otp) },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Verify Handoff")
                    }
                }
            }
        }
    }
}

@Composable
fun WeighbridgeSyncDialog(
    lot: CommodityLotEntity,
    onDismiss: () -> Unit,
    onWeigh: (Double, Double) -> Unit
) {
    var grossWeight by remember { mutableStateOf(lot.quantityKg.toString()) }
    var tareWeight by remember { mutableStateOf("450.0") } // Average truck tare

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Weighbridge Digital Sync", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Double-party scale matching. Automated system mismatch checks configured.", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = grossWeight,
                    onValueChange = { grossWeight = it },
                    label = { Text("Gross Weight (Loaded Truck) Kg") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = tareWeight,
                    onValueChange = { tareWeight = it },
                    label = { Text("Tare Weight (Empty Truck) Kg") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val w1 = grossWeight.toDoubleOrNull() ?: lot.quantityKg
                            val w2 = tareWeight.toDoubleOrNull() ?: 0.0
                            onWeigh(w1, w2)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Finalize Weighment")
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduleAuctionDialog(
    lot: CommodityLotEntity,
    onDismiss: () -> Unit,
    onSchedule: (Double, Int) -> Unit
) {
    var floorPrice by remember { mutableStateOf(lot.offerPricePerKg.toString()) }
    var biddingWindow by remember { mutableStateOf("24") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Schedule Public Auction", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = floorPrice,
                    onValueChange = { floorPrice = it },
                    label = { Text("Reserve Floor Price (₹/Kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = biddingWindow,
                    onValueChange = { biddingWindow = it },
                    label = { Text("Bidding Window (Hours)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val fp = floorPrice.toDoubleOrNull() ?: lot.offerPricePerKg
                            val bw = biddingWindow.toIntOrNull() ?: 24
                            onSchedule(fp, bw)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Publish Auction", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BidRoomDialog(
    auction: AuctionEntity,
    bids: List<BidEntity>,
    onDismiss: () -> Unit,
    onPlaceBid: (Double) -> Unit
) {
    var bidAmountStr by remember { mutableStateOf((auction.currentPricePerKg + 1.0).toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp).heightIn(max = 450.dp)) {
                Text(text = "Bidding Room: ${auction.commodityName}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Text(text = "Floor Price: ₹${auction.floorPricePerKg}/Kg  •  Load: ${auction.quantityKg} Kg", fontSize = 11.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                // Place Bid Form
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = bidAmountStr,
                        onValueChange = { bidAmountStr = it },
                        label = { Text("Enter Bid Price (₹/Kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.5f)
                    )
                    Button(
                        onClick = {
                            val valBid = bidAmountStr.toDoubleOrNull() ?: 0.0
                            onPlaceBid(valBid)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechAccentGold, contentColor = AgritechDarkGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Place Bid", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Ecosystem Bids History Logs", fontWeight = FontWeight.Bold, color = AgritechDarkGreen, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(6.dp))

                if (bids.isEmpty()) {
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text("No bids placed on this lot yet.", color = Color.Gray, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(bids) { bid ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AgritechTeal.copy(alpha = 0.05f))
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(bid.bidderName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DarkText)
                                    Text(formatTime(bid.timestamp), fontSize = 11.sp, color = Color.Gray)
                                }
                                Text("₹${bid.amountPerKg}/Kg", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AgritechTeal)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("Close Bid Room")
                }
            }
        }
    }
}

@Composable
fun LabAssayDialog(
    lot: CommodityLotEntity,
    onDismiss: () -> Unit,
    onSubmitAssay: (Double, Double, String) -> Unit
) {
    var moisture by remember { mutableStateOf("11.2") }
    var trash by remember { mutableStateOf("1.2") }
    var selectedGrade by remember { mutableStateOf("A") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Accredited Assaying Registry", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = moisture,
                    onValueChange = { moisture = it },
                    label = { Text("Certified Moisture content (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = trash,
                    onValueChange = { trash = it },
                    label = { Text("Trash & Admixture Percentage (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text("Accredited Quality Grade", fontSize = 12.sp, color = Color.Gray)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("A", "B", "C").forEach { grade ->
                        FilterChip(
                            selected = grade == selectedGrade,
                            onClick = { selectedGrade = grade },
                            label = { Text("Grade $grade") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val m = moisture.toDoubleOrNull() ?: 12.0
                            val t = trash.toDoubleOrNull() ?: 1.0
                            onSubmitAssay(m, t, selectedGrade)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechTeal),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Verify & Issue NWR Info")
                    }
                }
            }
        }
    }
}

@Composable
fun ResolveDisputeDialog(
    dispute: DisputeEntity,
    onDismiss: () -> Unit,
    onResolve: (String) -> Unit
) {
    var terms by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Mediate & Settle Dispute", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AgritechDarkGreen)
                Spacer(modifier = Modifier.height(8.dp))

                Text("System mismatch description:", fontSize = 11.sp, color = Color.Gray)
                Text(dispute.reason, fontSize = 13.sp, color = DarkText, modifier = Modifier.padding(vertical = 4.dp))

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = terms,
                    onValueChange = { terms = it },
                    label = { Text("Enter Arbitration & Resolution Terms") },
                    placeholder = { Text("e.g. Price adjusted. Tare verified.") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onResolve(terms) },
                        colors = ButtonDefaults.buttonColors(containerColor = AgritechMediumGreen),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("Apply Resolution Terms")
                    }
                }
            }
        }
    }
}
