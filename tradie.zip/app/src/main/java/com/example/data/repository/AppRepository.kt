package com.example.data.repository

import com.example.data.dao.AppDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class AppRepository(private val appDao: AppDao) {

    // --- Users ---
    val primaryUserFlow: Flow<UserEntity?> = appDao.getPrimaryUserFlow()
    val allUsersFlow: Flow<List<UserEntity>> = appDao.getAllUsersFlow()

    suspend fun getUserById(id: Int): UserEntity? = appDao.getUserById(id)
    suspend fun insertUser(user: UserEntity): Long = appDao.insertUser(user)
    suspend fun updateUser(user: UserEntity) = appDao.updateUser(user)

    // --- Farms ---
    fun getFarmsByUserIdFlow(userId: Int): Flow<List<FarmEntity>> = appDao.getFarmsByUserIdFlow(userId)
    suspend fun insertFarm(farm: FarmEntity): Long = appDao.insertFarm(farm)

    // --- Lots ---
    val allLotsFlow: Flow<List<CommodityLotEntity>> = appDao.getAllLotsFlow()
    fun getLotsByProducerIdFlow(producerId: Int): Flow<List<CommodityLotEntity>> = appDao.getLotsByProducerIdFlow(producerId)
    suspend fun getLotById(id: Int): CommodityLotEntity? = appDao.getLotById(id)
    suspend fun insertLot(lot: CommodityLotEntity): Long = appDao.insertLot(lot)
    suspend fun updateLot(lot: CommodityLotEntity) = appDao.updateLot(lot)

    // --- Auctions ---
    val allAuctionsFlow: Flow<List<AuctionEntity>> = appDao.getAllAuctionsFlow()
    suspend fun getAuctionById(id: Int): AuctionEntity? = appDao.getAuctionById(id)
    suspend fun insertAuction(auction: AuctionEntity): Long = appDao.insertAuction(auction)
    suspend fun updateAuction(auction: AuctionEntity) = appDao.updateAuction(auction)

    // --- Bids ---
    fun getBidsForAuctionFlow(auctionId: Int): Flow<List<BidEntity>> = appDao.getBidsForAuctionFlow(auctionId)
    suspend fun insertBid(bid: BidEntity): Long = appDao.insertBid(bid)

    // --- Warehouse Receipts ---
    val allWarehouseReceiptsFlow: Flow<List<WarehouseReceiptEntity>> = appDao.getAllWarehouseReceiptsFlow()
    suspend fun getWarehouseReceiptByLotId(lotId: Int): WarehouseReceiptEntity? = appDao.getWarehouseReceiptByLotId(lotId)
    suspend fun insertWarehouseReceipt(receipt: WarehouseReceiptEntity): Long = appDao.insertWarehouseReceipt(receipt)
    suspend fun updateWarehouseReceipt(receipt: WarehouseReceiptEntity) = appDao.updateWarehouseReceipt(receipt)

    // --- Transport Trips ---
    val allTransportTripsFlow: Flow<List<TransportTripEntity>> = appDao.getAllTransportTripsFlow()
    suspend fun getTransportTripByLotId(lotId: Int): TransportTripEntity? = appDao.getTransportTripByLotId(lotId)
    suspend fun insertTransportTrip(trip: TransportTripEntity): Long = appDao.insertTransportTrip(trip)
    suspend fun updateTransportTrip(trip: TransportTripEntity) = appDao.updateTransportTrip(trip)

    // --- Disputes ---
    val allDisputesFlow: Flow<List<DisputeEntity>> = appDao.getAllDisputesFlow()
    suspend fun insertDispute(dispute: DisputeEntity): Long = appDao.insertDispute(dispute)
    suspend fun updateDispute(dispute: DisputeEntity) = appDao.updateDispute(dispute)

    // --- Audit Logs ---
    val allAuditLogsFlow: Flow<List<AuditLogEntity>> = appDao.getAllAuditLogsFlow()
    suspend fun insertAuditLog(log: AuditLogEntity): Long = appDao.insertAuditLog(log)
}
