package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Users ---
    @Query("SELECT * FROM users LIMIT 1")
    fun getPrimaryUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Int): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    // --- Farms ---
    @Query("SELECT * FROM farms WHERE userId = :userId")
    fun getFarmsByUserIdFlow(userId: Int): Flow<List<FarmEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFarm(farm: FarmEntity): Long

    // --- Lots ---
    @Query("SELECT * FROM commodity_lots ORDER BY id DESC")
    fun getAllLotsFlow(): Flow<List<CommodityLotEntity>>

    @Query("SELECT * FROM commodity_lots WHERE producerId = :producerId ORDER BY id DESC")
    fun getLotsByProducerIdFlow(producerId: Int): Flow<List<CommodityLotEntity>>

    @Query("SELECT * FROM commodity_lots WHERE id = :id")
    suspend fun getLotById(id: Int): CommodityLotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLot(lot: CommodityLotEntity): Long

    @Update
    suspend fun updateLot(lot: CommodityLotEntity)

    // --- Auctions ---
    @Query("SELECT * FROM auctions ORDER BY id DESC")
    fun getAllAuctionsFlow(): Flow<List<AuctionEntity>>

    @Query("SELECT * FROM auctions WHERE id = :id")
    suspend fun getAuctionById(id: Int): AuctionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuction(auction: AuctionEntity): Long

    @Update
    suspend fun updateAuction(auction: AuctionEntity)

    // --- Bids ---
    @Query("SELECT * FROM bids WHERE auctionId = :auctionId ORDER BY amountPerKg DESC")
    fun getBidsForAuctionFlow(auctionId: Int): Flow<List<BidEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBid(bid: BidEntity): Long

    // --- Warehouse Receipts ---
    @Query("SELECT * FROM warehouse_receipts ORDER BY id DESC")
    fun getAllWarehouseReceiptsFlow(): Flow<List<WarehouseReceiptEntity>>

    @Query("SELECT * FROM warehouse_receipts WHERE lotId = :lotId LIMIT 1")
    suspend fun getWarehouseReceiptByLotId(lotId: Int): WarehouseReceiptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWarehouseReceipt(receipt: WarehouseReceiptEntity): Long

    @Update
    suspend fun updateWarehouseReceipt(receipt: WarehouseReceiptEntity)

    // --- Transport Trips ---
    @Query("SELECT * FROM transport_trips ORDER BY id DESC")
    fun getAllTransportTripsFlow(): Flow<List<TransportTripEntity>>

    @Query("SELECT * FROM transport_trips WHERE lotId = :lotId LIMIT 1")
    suspend fun getTransportTripByLotId(lotId: Int): TransportTripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransportTrip(trip: TransportTripEntity): Long

    @Update
    suspend fun updateTransportTrip(trip: TransportTripEntity)

    // --- Disputes ---
    @Query("SELECT * FROM disputes ORDER BY id DESC")
    fun getAllDisputesFlow(): Flow<List<DisputeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDispute(dispute: DisputeEntity): Long

    @Update
    suspend fun updateDispute(dispute: DisputeEntity)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs ORDER BY id DESC")
    fun getAllAuditLogsFlow(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long
}
