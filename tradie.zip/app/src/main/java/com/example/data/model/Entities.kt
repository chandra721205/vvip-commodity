package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val mobile: String,
    val roleName: String, // "Producer", "Agent", "Buyer", "Transporter", "Warehouse", "Finance", "TPV", "Admin"
    val orgName: String,
    val kycStatus: String, // "PENDING", "VERIFIED", "REJECTED"
    val tradieCoins: Int = 1000
)

@Entity(tableName = "farms")
data class FarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val farmName: String,
    val surveyNumber: String,
    val geoLat: Double,
    val geoLong: Double,
    val areaAcres: Double,
    val soilTestDate: String
)

@Entity(tableName = "commodity_lots")
data class CommodityLotEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val farmId: Int,
    val producerId: Int,
    val producerName: String,
    val commodityName: String,
    val variety: String,
    val grade: String, // "A", "B", "C", "Other"
    val quantityKg: Double,
    val offerPricePerKg: Double,
    val tokenId: String, // Generated unique asset twin token
    val status: String, // "CREATED", "TOKENIZED", "TRANSPORT_BOOKED", "RECEIVED_AT_YARD", "IN_AUCTION", "SOLD", "STORED", "PLEDGED"
    val selfDeclaredQuality: String,
    val thirdPartyVerified: Boolean = false,
    val labCertified: Boolean = false,
    val moistureContent: Double = 12.0,
    val trashPercentage: Double = 1.5,
    val imagePath: String = "",
    val commissionAgentId: Int = 0,
    val commissionAgentName: String = "",
    val warehouseId: Int = 0,
    val transportTripId: Int = 0,
    val disputeId: Int = 0
)

@Entity(tableName = "auctions")
data class AuctionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val lotId: Int,
    val commodityName: String,
    val quantityKg: Double,
    val floorPricePerKg: Double,
    val currentPricePerKg: Double,
    val highestBidderName: String = "",
    val highestBidderId: Int = 0,
    val startTime: Long,
    val endTime: Long,
    val biddingWindowHours: Int = 24,
    val status: String // "SCHEDULED", "LIVE", "CLOSED", "REJECTED"
)

@Entity(tableName = "bids")
data class BidEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val auctionId: Int,
    val bidderId: Int,
    val bidderName: String,
    val amountPerKg: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "warehouse_receipts")
data class WarehouseReceiptEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val warehouseName: String,
    val lotId: Int,
    val commodityName: String,
    val quantityKg: Double,
    val status: String, // "ACTIVE", "PLEDGED", "RELEASE_REQUESTED", "RELEASED"
    val receiptDate: Long = System.currentTimeMillis(),
    val temperatureCelsius: Double = 22.5,
    val humidityPercentage: Double = 55.0
)

@Entity(tableName = "transport_trips")
data class TransportTripEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val lotId: Int,
    val commodityName: String,
    val quantityKg: Double,
    val transporterName: String,
    val driverName: String,
    val pickupOtp: String, // 4-digit code
    val deliveryOtp: String, // 4-digit code
    val status: String, // "BOOKED", "PICKED_UP", "IN_TRANSIT", "DELIVERED"
    val currentLocation: String = "Origin Farm",
    val tripCharges: Double = 2500.0
)

@Entity(tableName = "disputes")
data class DisputeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val entityType: String, // "WEIGHMENT", "QUALITY", "LOGISTICS", "PAYMENT"
    val entityId: Int,
    val initiatorName: String,
    val reason: String,
    val status: String, // "OPEN", "INVESTIGATING", "RESOLVED"
    val resolutionDetails: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val action: String, // "USER_SIGNUP", "LOT_TOKENIZED", "BID_PLACED", "OTP_VERIFIED", "DISPUTE_RAISED"
    val entityType: String,
    val entityId: Int,
    val userName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String
)
