package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class TradieViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    // Central shared flows
    val primaryUser: StateFlow<UserEntity?>
    val allUsers: StateFlow<List<UserEntity>>
    val allLots: StateFlow<List<CommodityLotEntity>>
    val allAuctions: StateFlow<List<AuctionEntity>>
    val allWarehouseReceipts: StateFlow<List<WarehouseReceiptEntity>>
    val allTransportTrips: StateFlow<List<TransportTripEntity>>
    val allDisputes: StateFlow<List<DisputeEntity>>
    val allAuditLogs: StateFlow<List<AuditLogEntity>>

    // Selected lot detail, selected auction, active bid list, etc.
    private val _selectedLotId = MutableStateFlow<Int?>(null)
    val selectedLotId = _selectedLotId.asStateFlow()

    private val _activeBids = MutableStateFlow<List<BidEntity>>(emptyList())
    val activeBids = _activeBids.asStateFlow()

    // Navigation and UX states
    private val _activeRole = MutableStateFlow("Producer") // "Producer", "Agent", "Buyer", "Transporter", "Warehouse", "Finance", "TPV", "Admin"
    val activeRole = _activeRole.asStateFlow()

    private val _currentScreen = MutableStateFlow("Dashboard") // "Dashboard", "Plots", "Lots", "Market", "Trips", "Storage", "Finance", "Insurance", "Labs", "Disputes", "Admin"
    val currentScreen = _currentScreen.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database.appDao())

        // Collect DB status flow safely
        primaryUser = repository.primaryUserFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        allUsers = repository.allUsersFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allLots = repository.allLotsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allAuctions = repository.allAuctionsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allWarehouseReceipts = repository.allWarehouseReceiptsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allTransportTrips = repository.allTransportTripsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allDisputes = repository.allDisputesFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allAuditLogs = repository.allAuditLogsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allLotsStream()
        
        // Expose other streams
        // We will seed the database with initial records on first launch if it's empty.
        viewModelScope.launch {
            prepInitialMockData()
        }
    }

    // Secondary UI States
    val myFarms: StateFlow<List<FarmEntity>> = repository.getFarmsByUserIdFlow(1).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )
    val myLots: StateFlow<List<CommodityLotEntity>> = repository.allLotsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private fun allLotsStream() {
        // Collect DB changes and print or trigger state adjustments if needed
    }

    private suspend fun prepInitialMockData() {
        val dao = AppDatabase.getDatabase(getApplication()).appDao()
        
        // Check if seeded
        val existingUsers = dao.getUserById(1)
        if (existingUsers != null) return // Already seeded!

        // 1. Create a few users of different roles
        dao.insertUser(UserEntity(1, "Anil Kumar", "+91 98765 43210", "Producer", "Kumar Organic Farms", "VERIFIED", 2500))
        dao.insertUser(UserEntity(2, "Rajesh Mandi Agent", "+91 87654 32109", "Agent", "Mandi Brothers Ltd.", "VERIFIED", 5000))
        dao.insertUser(UserEntity(3, "Subhash Grain Traders", "+91 76543 21098", "Buyer", "GrainCorp Exporters", "VERIFIED", 15000))
        dao.insertUser(UserEntity(4, "Sher Singh Logistics", "+91 65432 10987", "Transporter", "Singh Cargo Carriers", "VERIFIED", 1200))
        dao.insertUser(UserEntity(5, "Mandi Yard Warehouse", "+91 54321 09876", "Warehouse", "State Warehouse Corp", "VERIFIED", 1000))
        dao.insertUser(UserEntity(6, "NABARD Pledge Credit", "+91 43210 98765", "Finance", "NABARD Financials", "VERIFIED", 10000))
        dao.insertUser(UserEntity(7, "SGS Agrochemical Labs", "+91 32109 87654", "TPV", "SGS Assayers", "VERIFIED", 500))

        // 2. Insert Farm Plots
        dao.insertFarm(FarmEntity(1, 1, "Sona Masuri Valley Plot", "SRV-412/9B", 16.8524, 74.5812, 8.5, "2026-05-10"))
        dao.insertFarm(FarmEntity(2, 1, "Organic Turmeric Block", "SRV-104/A", 16.8550, 74.5840, 4.0, "2026-06-01"))

        // 3. Insert Lots
        val lotId1 = dao.insertLot(CommodityLotEntity(
            id = 1,
            farmId = 1,
            producerId = 1,
            producerName = "Anil Kumar",
            commodityName = "Sona Masuri Rice",
            variety = "Premium Aged",
            grade = "A",
            quantityKg = 12000.0,
            offerPricePerKg = 48.0,
            tokenId = "TRD-RICE-" + UUID.randomUUID().toString().take(6).uppercase(),
            status = "TOKENIZED",
            selfDeclaredQuality = "Moisture: 11.5%, Purity: 98%"
        ))

        val lotId2 = dao.insertLot(CommodityLotEntity(
            id = 2,
            farmId = 2,
            producerId = 1,
            producerName = "Anil Kumar",
            commodityName = "Organic Turmeric",
            variety = "Selam Quality",
            grade = "A",
            quantityKg = 4500.0,
            offerPricePerKg = 110.0,
            tokenId = "TRD-TURM-" + UUID.randomUUID().toString().take(6).uppercase(),
            status = "STORED",
            selfDeclaredQuality = "Moisture: 9.0%, Curcumin: 5.2%"
        ))

        // 4. Create an Auction for Turmeric Lot (which is stored)
        val auctionId = dao.insertAuction(AuctionEntity(
            id = 1,
            lotId = 2,
            commodityName = "Organic Turmeric",
            quantityKg = 4500.0,
            floorPricePerKg = 110.0,
            currentPricePerKg = 112.5,
            highestBidderName = "Subhash Grain Traders",
            highestBidderId = 3,
            startTime = System.currentTimeMillis() - 3600000,
            endTime = System.currentTimeMillis() + 82800000,
            biddingWindowHours = 24,
            status = "LIVE"
        ))

        // 5. Add initial Bids to the Auction
        dao.insertBid(BidEntity(1, 1, 3, "Subhash Grain Traders", 112.5, System.currentTimeMillis() - 1800000))

        // 6. Create initial Warehouse Receipt
        dao.insertWarehouseReceipt(WarehouseReceiptEntity(
            id = 1,
            warehouseName = "State Warehouse Corp - Chamber 4",
            lotId = 2,
            commodityName = "Organic Turmeric",
            quantityKg = 4500.0,
            status = "ACTIVE"
        ))

        // 7. Write Initial Audit Logs
        dao.insertAuditLog(AuditLogEntity(1, "USER_SIGNUP", "USER", 1, "System", System.currentTimeMillis() - 7200000, "Anil Kumar successfully completed Bio-KYC onboarding with survey details."))
        dao.insertAuditLog(AuditLogEntity(2, "LOT_TOKENIZED", "LOT", 1, "Anil Kumar", System.currentTimeMillis() - 3600000, "Grained Lot TRD-RICE-98A registered with dynamic agricultural provenance mapping."))
        dao.insertAuditLog(AuditLogEntity(3, "OTP_VERIFIED", "LOT", 2, "State Warehouse Corp", System.currentTimeMillis() - 1200000, "Secure warehouse receipt issued following OTP physical confirmation (OTP-RCPT)."))
    }

    // Helper functions for Room to bypass compiler typecheck
    private fun AppDatabase.appDaoHelper() = this.appDao()

    // --- Stakeholder Switching ---
    fun switchRole(newRole: String) {
        _activeRole.value = newRole
        // Direct screen route switching depending on role defaults
        _currentScreen.value = when (newRole) {
            "Producer" -> "Dashboard"
            "Agent" -> "Dashboard"
            "Buyer" -> "Market"
            "Transporter" -> "Trips"
            "Warehouse" -> "Storage"
            "Finance" -> "Finance"
            "TPV" -> "Labs"
            "Admin" -> "Admin"
            else -> "Dashboard"
        }
        logAudit("ROLE_SWITCHED", "USER", 1, "Switched active operator context to $newRole")
    }

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    // --- PRODUCER WORKFLOWS ---
    fun addFarmPlot(name: String, surveyNo: String, acres: Double, lat: Double, long: Double) {
        viewModelScope.launch {
            val dao = AppDatabase.getDatabase(getApplication()).appDao()
            dao.insertFarm(FarmEntity(
                userId = 1,
                farmName = name,
                surveyNumber = surveyNo,
                geoLat = lat,
                geoLong = long,
                areaAcres = acres,
                soilTestDate = "2026-06-20"
            ))
            logAudit("FARM_ADDED", "FARM", 0, "Added farm plot $name with survey number $surveyNo")
        }
    }

    fun createAndTokenizeLot(
        farmId: Int,
        commodity: String,
        variety: String,
        grade: String,
        quantity: Double,
        price: Double,
        qualitySelf: String
    ) {
        viewModelScope.launch {
            val dao = AppDatabase.getDatabase(getApplication()).appDao()
            val token = "TRD-" + commodity.take(4).uppercase() + "-" + UUID.randomUUID().toString().take(6).uppercase()
            val lotId = dao.insertLot(CommodityLotEntity(
                farmId = farmId,
                producerId = 1,
                producerName = "Anil Kumar",
                commodityName = commodity,
                variety = variety,
                grade = grade,
                quantityKg = quantity,
                offerPricePerKg = price,
                tokenId = token,
                status = "TOKENIZED",
                selfDeclaredQuality = qualitySelf
            ))
            logAudit("LOT_TOKENIZED", "LOT", lotId.toInt(), "Created tokenized digital twin lot $token for $commodity")
        }
    }

    // --- LOGISTICS WORKFLOWS ---

    fun bookTransportForLot(lotId: Int, transporterName: String) {
        viewModelScope.launch {
            val db = getDatabase()
            val lot = db.appDao().getLotById(lotId) ?: return@launch
            val pickupOtp = (1000..9999).random().toString()
            val deliveryOtp = (1000..9999).random().toString()
            
            val tripId = db.appDao().insertTransportTrip(TransportTripEntity(
                lotId = lotId,
                commodityName = lot.commodityName,
                quantityKg = lot.quantityKg,
                transporterName = transporterName,
                driverName = "Gurbaksh Singh",
                pickupOtp = pickupOtp,
                deliveryOtp = deliveryOtp,
                status = "BOOKED"
            ))

            db.appDao().updateLot(lot.copy(
                status = "TRANSPORT_BOOKED",
                transportTripId = tripId.toInt()
            ))

            logAudit("TRANSPORT_BOOKED", "LOT", lotId, "Booked cargo trip with $transporterName. Verification OTPs generated.")
        }
    }

    fun verifyPickupOTP(tripId: Int, inputOtp: String): Boolean {
        var success = false
        // Fetch trip, verify otp, transition trip status to "IN_TRANSIT" and update audit log
        return success
    }

    fun performPickupHandoff(tripId: Int, otp: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val trips = db.appDao().getAllTransportTripsFlow().first()
            val trip = trips.find { it.id == tripId }
            if (trip != null && trip.pickupOtp == otp) {
                db.appDao().updateTransportTrip(trip.copy(status = "IN_TRANSIT", currentLocation = "On Mandi Highway"))
                val lot = db.appDao().getLotById(trip.lotId)
                if (lot != null) {
                    db.appDao().updateLot(lot.copy(status = "TRANSPORT_BOOKED"))
                }
                logAudit("OTP_VERIFIED", "TRIP", tripId, "OTP-HAND (Pickup) Verified. Cargo is officially in transit.")
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }

    fun performDeliveryHandoff(tripId: Int, otp: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val trips = db.appDao().getAllTransportTripsFlow().first()
            val trip = trips.find { it.id == tripId }
            if (trip != null && trip.deliveryOtp == otp) {
                db.appDao().updateTransportTrip(trip.copy(status = "DELIVERED", currentLocation = "Mandi Market Yard"))
                val lot = db.appDao().getLotById(trip.lotId)
                if (lot != null) {
                    db.appDao().updateLot(lot.copy(status = "RECEIVED_AT_YARD"))
                }
                logAudit("OTP_VERIFIED", "TRIP", tripId, "OTP-DELIV Verified. Yard Manager completed secure physical receipt.")
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }

    // --- COMMISSION AGENT & WEIGHBRIDGE WORKFLOWS ---
    fun performWeighbridgeEntry(lotId: Int, weight1: Double, weight2: Double, onMismatch: (Boolean) -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val lot = db.appDao().getLotById(lotId) ?: return@launch
            val actualWeight = weight1 - weight2
            val expectedWeight = lot.quantityKg
            val difference = Math.abs(actualWeight - expectedWeight)
            val threshold = expectedWeight * 0.02 // 2% mismatch tolerance

            if (difference > threshold) {
                // Raise quality/weighment mismatch dispute
                val disputeId = db.appDao().insertDispute(DisputeEntity(
                    entityType = "WEIGHMENT",
                    entityId = lotId,
                    initiatorName = "Weighbridge Operator",
                    reason = "Weighbridge actual ($actualWeight kg) differs from declared ($expectedWeight kg) by ${String.format("%.1f", difference)} kg.",
                    status = "OPEN"
                ))
                db.appDao().updateLot(lot.copy(
                    status = "RECEIVED_AT_YARD",
                    disputeId = disputeId.toInt()
                ))
                logAudit("WEIGHMENT_MISMATCH", "LOT", lotId, "Dispute raised: weight mismatch of ${String.format("%.1f", difference)} kg exceeds 2% tolerance.")
                onMismatch(true)
            } else {
                db.appDao().updateLot(lot.copy(
                    quantityKg = actualWeight, // Override with true weighbridge weight
                    status = "RECEIVED_AT_YARD"
                ))
                logAudit("WEIGHMENT_VERIFIED", "LOT", lotId, "Weighbridge weighment verified and finalized at $actualWeight kg.")
                onMismatch(false)
            }
        }
    }

    fun scheduleAuctionForLot(lotId: Int, floorPrice: Double, hours: Int) {
        viewModelScope.launch {
            val db = getDatabase()
            val lot = db.appDao().getLotById(lotId) ?: return@launch
            
            db.appDao().insertAuction(AuctionEntity(
                lotId = lotId,
                commodityName = lot.commodityName,
                quantityKg = lot.quantityKg,
                floorPricePerKg = floorPrice,
                currentPricePerKg = floorPrice,
                startTime = System.currentTimeMillis(),
                endTime = System.currentTimeMillis() + (hours * 3600000L),
                biddingWindowHours = hours,
                status = "LIVE"
            ))

            db.appDao().updateLot(lot.copy(status = "IN_AUCTION"))
            logAudit("AUCTION_SCHEDULED", "LOT", lotId, "Auction scheduled with a floor price of ₹$floorPrice/kg for $hours hours.")
        }
    }

    // --- BUYER BID ROOM WORKFLOWS ---
    fun placeBid(auctionId: Int, amountPerKg: Double, bidderId: Int, bidderName: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val auction = db.appDao().getAuctionById(auctionId)
            if (auction == null) {
                onResult(false, "Auction not found")
                return@launch
            }
            if (amountPerKg <= auction.currentPricePerKg) {
                onResult(false, "Bid must be greater than current highest price ₹${auction.currentPricePerKg}/kg")
                return@launch
            }

            // Record Bid
            db.appDao().insertBid(BidEntity(
                auctionId = auctionId,
                bidderId = bidderId,
                bidderName = bidderName,
                amountPerKg = amountPerKg
            ))

            // Update Auction Price
            db.appDao().updateAuction(auction.copy(
                currentPricePerKg = amountPerKg,
                highestBidderName = bidderName,
                highestBidderId = bidderId
            ))

            logAudit("BID_PLACED", "AUCTION", auctionId, "$bidderName placed highest bid of ₹$amountPerKg/kg")
            onResult(true, "Bid successfully submitted!")
        }
    }

    fun getBidsForAuctionFlow(auctionId: Int): kotlinx.coroutines.flow.Flow<List<BidEntity>> {
        return repository.getBidsForAuctionFlow(auctionId)
    }

    fun completePrimaryUserBioKYC(onComplete: () -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val u = db.appDao().getUserById(1)
            if (u != null) {
                db.appDao().updateUser(u.copy(kycStatus = "VERIFIED"))
                logAudit("KYC_VERIFIED", "USER", 1, "Anil Kumar completed Bio-KYC verification successfully.")
                onComplete()
            }
        }
    }

    fun closeAuctionAndAcceptWinner(auctionId: Int) {
        viewModelScope.launch {
            val db = getDatabase()
            val auction = db.appDao().getAuctionById(auctionId) ?: return@launch
            if (auction.status != "LIVE") return@launch

            db.appDao().updateAuction(auction.copy(status = "CLOSED"))
            val lot = db.appDao().getLotById(auction.lotId)
            if (lot != null) {
                db.appDao().updateLot(lot.copy(status = "SOLD"))
            }

            // Create a safe billing entry/audit log
            logAudit("AUCTION_CLOSED", "AUCTION", auctionId, "Auction closed. Accepted winning bid from ${auction.highestBidderName} at ₹${auction.currentPricePerKg}/kg.")
        }
    }

    // --- WAREHOUSE & FINANCE WORKFLOWS ---
    fun generateWarehouseReceipt(lotId: Int, warehouseName: String) {
        viewModelScope.launch {
            val db = getDatabase()
            val lot = db.appDao().getLotById(lotId) ?: return@launch
            
            db.appDao().insertWarehouseReceipt(WarehouseReceiptEntity(
                warehouseName = warehouseName,
                lotId = lotId,
                commodityName = lot.commodityName,
                quantityKg = lot.quantityKg,
                status = "ACTIVE"
            ))

            db.appDao().updateLot(lot.copy(status = "STORED"))
            logAudit("WAREHOUSE_RECEIPT_ISSUED", "LOT", lotId, "Negotiable warehouse storage receipt generated in Chamber 7 for ${lot.commodityName}.")
        }
    }

    fun applyForPledgeLoan(receiptId: Int, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val db = getDatabase()
            val receipts = db.appDao().getAllWarehouseReceiptsFlow().first()
            val receipt = receipts.find { it.id == receiptId } ?: return@launch
            
            val lot = db.appDao().getLotById(receipt.lotId) ?: return@launch
            val expectedValue = lot.quantityKg * lot.offerPricePerKg
            val loanAmountAllowed = expectedValue * 0.70 // 70% collateral LTV

            db.appDao().insertWarehouseReceipt(receipt.copy(status = "PLEDGED"))
            db.appDao().updateLot(lot.copy(status = "PLEDGED"))

            // Trigger Loan Advance
            logAudit("PLEDGE_LOAN_APPROVED", "LOAN", receiptId, "NABARD credit line approved. Disbursed 70% LTV loan of ₹${String.format("%.2f", loanAmountAllowed)} directly to Producer ledger.")
            
            // Add funds to producer coin balance
            val producer = db.appDao().getUserById(1)
            if (producer != null) {
                db.appDao().updateUser(producer.copy(tradieCoins = producer.tradieCoins + (loanAmountAllowed / 10).toInt()))
            }

            onComplete(true)
        }
    }

    // --- QUALITY VERIFICATION (TPV) ---
    fun submitQualityAssay(lotId: Int, verifierName: String, moisture: Double, trash: Double, grade: String) {
        viewModelScope.launch {
            val db = getDatabase()
            val lot = db.appDao().getLotById(lotId) ?: return@launch

            db.appDao().updateLot(lot.copy(
                grade = grade,
                moistureContent = moisture,
                trashPercentage = trash,
                thirdPartyVerified = true,
                labCertified = true
            ))

            logAudit("QUALITY_CERTIFIED", "LOT", lotId, "SGS Laboratory issued certified twin report: Grade $grade, Moisture $moisture%, Trash $trash%.")
        }
    }

    // --- DISPUTE RESOLUTION ---
    fun resolveDispute(disputeId: Int, resolution: String) {
        viewModelScope.launch {
            val db = getDatabase()
            val disputes = db.appDao().getAllDisputesFlow().first()
            val dispute = disputes.find { it.id == disputeId } ?: return@launch

            db.appDao().updateDispute(dispute.copy(
                status = "RESOLVED",
                resolutionDetails = resolution
            ))

            logAudit("DISPUTE_RESOLVED", "DISPUTE", disputeId, "Mediation completed. Resolution applied: $resolution")
        }
    }

    // --- Database Helper ---
    private fun getDatabase(): AppDatabase {
        return AppDatabase.getDatabase(getApplication())
    }

    private fun logAudit(action: String, entityType: String, entityId: Int, details: String) {
        viewModelScope.launch {
            val db = getDatabase()
            db.appDao().insertAuditLog(AuditLogEntity(
                action = action,
                entityType = entityType,
                entityId = entityId,
                userName = when (_activeRole.value) {
                    "Producer" -> "Anil Kumar (Producer)"
                    "Agent" -> "Rajesh Mandi Agent (CA)"
                    "Buyer" -> "Subhash Grain Traders (Buyer)"
                    "Transporter" -> "Sher Singh Logistics"
                    "Warehouse" -> "State Warehouse Corp"
                    "Finance" -> "NABARD Pledge Credit"
                    "TPV" -> "SGS Agrochemical Labs"
                    else -> "System Operator"
                },
                details = details
            ))
        }
    }
}
